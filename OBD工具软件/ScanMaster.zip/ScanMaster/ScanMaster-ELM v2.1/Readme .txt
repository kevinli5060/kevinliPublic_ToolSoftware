hello guys!

my website:
     http://www.mrzuo.com
     http://www.rs4all.com
     http://www.yes-ican.us
     http://www.links-rapidshare.com

Want big money? just sign up with these links and start earn money
http://bux.to/?r=zuoxingyu
http://www.neobux.com/?rh=7A756F78696E677975
http://hotfile.com/register.html?reff=250007
http://www.easy-share.com/p/2034091

Find your friends below links:

http://friendfinder.com/go/g948943-pmem
http://asiafriendfinder.com/go/g948943-pmem
http://adultfriendfinder.com/go/g948943-ppc
http://alt.com/go/g948943-ppc
http://frenchfriendfinder.com/go/g948943-pmem
http://friendfinder.com/go/f184912-pmem 
http://guanxi.com/go/g948943-pmem
http://italianfriendfinder.com/go/g948943-pmem
http://nudecards.com/go/g948943-pmem

password: www.rs4all.com